const Regions = [
  {
    id: 1, name: '서울',
  },
  {
    id: 2, name: '대전',
  },
  {
    id: 3, name: '대구',
  },
  {
    id: 4, name: '부산',
  },
  {
    id: 5, name: '광주',
  },
  {
    id: 6, name: '강원도',
  },
  {
    id: 7, name: '인천',
  },
  {
    id: 181, name: '제주도',
  },
];

export default Regions;
