const Categories = [
  {
    id: 1, name: '한식',
  },
  {
    id: 2, name: '중식',
  },
  {
    id: 3, name: '일식',
  },
  {
    id: 4, name: '양식',
  },
  {
    id: 5, name: '분식',
  },
  {
    id: 196, name: '짬뽕밥',
  },
];

export default Categories;
