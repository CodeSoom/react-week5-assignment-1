import React from 'react';

export default function Restaurant({ name }) {
  return (
    <>
      <li>{name}</li>
    </>
  );
}
