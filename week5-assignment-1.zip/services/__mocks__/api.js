export async function fetchCategories() {
  return [];
}

export async function fetchRegions() {
  return [];
}

export async function fetchRestaurants() {
  return [];
}
